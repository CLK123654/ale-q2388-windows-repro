from __future__ import annotations

from airflow import DAG
from airflow.operators.empty import EmptyOperator
from pendulum import datetime


with DAG(
    dag_id="remote_tile_delivery",
    schedule=None,
    start_date=datetime(2026, 1, 1, tz="UTC"),
    catchup=False,
) as dag:
    fixed_shards = [EmptyOperator(task_id=f"process_shard_{index}") for index in range(4)]
