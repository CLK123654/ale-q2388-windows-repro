from __future__ import annotations
from pendulum import parse
from remote_tile_delivery import dag

def run_batch(batch_id: str, family: str, manifest_file: str, logical_date: str) -> None:
    dag.test(execution_date=parse(logical_date), run_conf={"batch_id": batch_id, "family": family, "manifest_file": manifest_file})
