# 遥感切片分片续跑材料

dags目录保存候选DAG，tools目录保存批次运行入口，results目录保存分片处理账、批次摘要和DAG结构，checkpoints目录保存可复用分片状态，release-summary.json供值班人员安排维护窗。
